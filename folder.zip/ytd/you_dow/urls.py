from django.contrib import admin
from django.urls import path
from . import views
app_name='downloader'

urlpatterns = [
    path('',views.home, name='homepage'),
    path('result', views.submit , name='submit'),
    # path('result/<resolution>/', views.Video_down, name='download_video'),
    # path('result_audio/<abr>/', views.Audio_down , name='Audio_down'),
    path ('result/<r>/', views.twitter_down, name='twitter_down')
]