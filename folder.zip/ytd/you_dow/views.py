from django.shortcuts import render
from pytube import YouTube
import pafy
import os
import re
import youtube_dl


def home(request):
    return render(request, 'ytb_main.html ')


def submit(request):
    global url
    url = request.GET.get('URL')
    regex_youtube = r'^(http(s)?:\/\/)?((w){3}.)?youtu(be|.be)?(\.com)?\/.+'
    regex_twitter = r'^(http(s)?:\/\/)?((w){3}.)?twitter?(\.com)?\/.+'
    if re.match(regex_youtube, url):

        obj1 = pafy.new(url)
        obj = YouTube(url)
        title = obj.title
        length = obj1.duration

        video = obj.streams.filter(progressive=True).asc()
        audio = obj.streams.filter(only_audio=True).asc()

        embed = url[-11:]
        embd = "https://www.youtube.com/embed/"+embed
        video = list(dict.fromkeys(video))
        audio = list(dict.fromkeys(audio))
        ext = []
        for i in audio:
            meta = (i.mime_type[6:])
            ext.append(str(meta))

        return render(request, 'yt_download.html', {'url': url, "audio": audio, "video": video, "embd": embd, "title": title, "length": length, "audio_extension": ext})
    elif re.match(regex_twitter, url):
        ydl_opts = {}
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            meta = ydl.extract_info(url, download=False)

        
        urls = []
        formats = []
        filesize = []
        width = []
        height = []
        extension = []
        reso_twitter= []

        for k, v in meta.items():
            if k == "duration":
                if v >60:
                    duration=str(round(v/60,2)) + " min"            
                else:
                    duration=str(round(v,1)) +" sec"

            elif k == 'title':
                title = v
                # print("title", v)
            elif k == "like_count":
                pass
                # print("like_Count", v)
            elif k == 'thumbnail':
                thumbnail = v
                # print("thumbnail--->",v)
            elif k == "formats":
                for i in v:
                    for a, b in i.items():
                        # print(a, "-->", b)
                        if a == "url":
                            urls.append(b)
                            # print(v)
                        elif a == "format":
                            formats.append(b)
                        elif a == "tbr":
                            if int(b) > 999999:
                                c = f'{round(int(b) / 1000000,2)}gb'
                                filesize.append(c)
                            elif int(b) > 999:
                                c = f'{round(int(b)/1000,2)}mb'
                                filesize.append(c)
                            else:
                                c = f'{round(int(b),2)}kb'
                                filesize.append(c)
                            
                        elif a == "width":
                            width.append(b)
                        elif a == "height":
                            height.append(b)
                        elif a == 'ext':
                            extension.append(b)

        filesize = list(dict.fromkeys(filesize))
        height = list(dict.fromkeys(height))
        width = list(dict.fromkeys(width))
        extension = extension[0:len(filesize)]

        for i in zip(width,height):
            res = str(i[0])+"x"+str(i[1])
            reso_twitter.append(res)
        # print(width)
        # print(extension)
        return render(request, 'twitter_dow.html', {"title":title,"reso_twitter":reso_twitter,"filesize":filesize})
        
        # print(thumbnail)


# def Video_down(request, resolution):
#     global url
#     # print(resolution)
#     # result= YouTube(url).streams.filter(progressive=True).asc()

#     # print(result)
#     # print("This is video function"+resolution)

#     if request.method == 'POST':
#         result = YouTube(url).streams.filter(progressive=True).asc()

#         for i in result:
#             if i.resolution == resolution:
#                 result.get_by_itag(i.itag).download('/download')

#     return render(request, 'ytb_main.html')


# def Audio_down(request, abr):
#     global url

#     # print(abr)
#     # path = os.path.expanduser('~')
#     # dirs=path='/Downloads'
#     if request.method == 'POST':
#         obj = YouTube(url)
#         result_audio = obj.streams.filter(only_audio=True).asc()
#         # print(result_audio)
#         for i in result_audio:

#             if abr == 'mp3' and i.abr == '128kbps':

#                 out_file = result_audio.get_by_itag(
#                     i.itag).download('/download')
#                 base, ext = os.path.splitext(out_file)
#                 new_file = base + '.mp3'
#                 os.rename(out_file, new_file)
#                 print('Successfully Downloaded in Gallery')
#             elif i.abr == abr:
#                 result_audio.get_by_itag(i.itag).download('/download')
#                 print('Successfully Downloaded in Gallery')

#     return render(request, 'ytb_main.html')

def twitter_down(request,r):
    print((r))
    return render(request, 'ytb_main.html')